import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  MessageSquare, Shield, Settings as SettingsIcon, Languages, ChevronRight,
  FileText, Upload, Send, Trash2, User, LogOut, Mic, BrainCircuit,
  ChevronDown, ChevronUp, BarChart2, FolderOpen, ThumbsUp, ThumbsDown,
  RefreshCw, X, CheckCircle, AlertCircle, Clock,
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, AreaChart, Area,
} from 'recharts';

import type { ChatMessage, QuerySettings, ChatSession, IngestedDocument, AnalyticsData } from './api';
import {
  uploadPdf, streamQuery, login, transcribeAudio,
  getSessions, createSession, getSessionMessages, deleteSession,
  listDocuments, deleteDocument, submitFeedback, getAnalytics, getTaskStatus,
} from './api';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ── Thinking Block ──────────────────────────────────────────────────────────
const ThinkingBlock = ({ content }: { content: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="mb-4 border border-border/50 rounded-xl overflow-hidden bg-accent/20">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-3 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
      >
        <span className="flex items-center gap-2"><BrainCircuit className="w-4 h-4" /> Agent Reasoning &amp; Tool Calls</span>
        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 pb-4 text-[11px] font-mono text-muted-foreground whitespace-pre-wrap border-t border-border/50"
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ── Message Formatter ───────────────────────────────────────────────────────
const formatMessage = (content: string) => {
  if (!content) return null;
  let thinkContent = '';
  let mainContent = content;
  const endIdx = content.lastIndexOf('</think>');
  if (endIdx !== -1) {
    const startIdx = content.indexOf('<think>');
    if (startIdx !== -1 && startIdx < endIdx) {
      thinkContent = content.substring(startIdx + 7, endIdx).trim();
      mainContent = (content.substring(0, startIdx) + content.substring(endIdx + 8)).trim();
    } else {
      thinkContent = content.substring(0, endIdx).trim();
      mainContent = content.substring(endIdx + 8).trim();
    }
    mainContent = mainContent.replace(/<tool_call>[\s\S]*?<\/tool_call>/g, '').trim();
    return (
      <div className="space-y-2">
        <ThinkingBlock content={thinkContent} />
        {mainContent && (
          <div className="markdown-body prose prose-sm prose-invert max-w-none">
            <ReactMarkdown>{mainContent}</ReactMarkdown>
          </div>
        )}
      </div>
    );
  }
  const clean = content.replace(/<tool_call>[\s\S]*?<\/tool_call>/g, '').trim();
  return (
    <div className="markdown-body prose prose-sm prose-invert max-w-none">
      <ReactMarkdown>{clean || content}</ReactMarkdown>
    </div>
  );
};

// ── Toast ───────────────────────────────────────────────────────────────────
interface Toast { id: string; message: string; type: 'success' | 'error' | 'info' }
const ToastContainer = ({ toasts, remove }: { toasts: Toast[]; remove: (id: string) => void }) => (
  <div className="fixed bottom-6 right-6 z-[100] flex flex-col gap-2 pointer-events-none">
    <AnimatePresence>
      {toasts.map(t => (
        <motion.div
          key={t.id}
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className={cn(
            'flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl border text-sm font-medium pointer-events-auto max-w-sm',
            t.type === 'success' && 'bg-green-950/90 border-green-700 text-green-200',
            t.type === 'error'   && 'bg-red-950/90 border-red-700 text-red-200',
            t.type === 'info'    && 'bg-card border-border text-foreground',
          )}
        >
          {t.type === 'success' && <CheckCircle className="w-4 h-4 text-green-400 shrink-0" />}
          {t.type === 'error'   && <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
          {t.type === 'info'    && <Clock className="w-4 h-4 text-primary shrink-0" />}
          <span className="flex-1">{t.message}</span>
          <button onClick={() => remove(t.id)} className="opacity-60 hover:opacity-100"><X className="w-3.5 h-3.5" /></button>
        </motion.div>
      ))}
    </AnimatePresence>
  </div>
);

// ── Upload Progress Modal ────────────────────────────────────────────────────
const UploadProgress = ({ filename, pct, status }: { filename: string; pct: number; status: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0 }}
    className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-card border border-border rounded-2xl p-4 shadow-2xl w-80"
  >
    <div className="flex items-center gap-3 mb-3">
      <Upload className="w-5 h-5 text-primary shrink-0" />
      <span className="text-sm font-semibold truncate flex-1">{filename}</span>
    </div>
    <div className="w-full bg-accent rounded-full h-1.5 overflow-hidden">
      <motion.div
        className="h-full bg-primary rounded-full"
        animate={{ width: `${pct}%` }}
        transition={{ ease: 'easeOut' }}
      />
    </div>
    <div className="text-[11px] text-muted-foreground mt-2 flex justify-between">
      <span>{status}</span>
      <span>{pct}%</span>
    </div>
  </motion.div>
);

// ── Analytics Dashboard ──────────────────────────────────────────────────────
const AnalyticsDashboard = () => {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchAnalytics = useCallback(async () => {
    setLoading(true);
    try {
      setData(await getAnalytics());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAnalytics(); }, [fetchAnalytics]);

  if (loading) return (
    <div className="flex-1 flex items-center justify-center">
      <RefreshCw className="w-8 h-8 text-primary animate-spin" />
    </div>
  );
  if (!data) return <div className="p-8 text-center text-muted-foreground">Failed to load analytics.</div>;

  const totalEmployees = data.department_metrics.reduce((a, d) => a + d.employee_count, 0);
  const cacheHitRate = data.total_cache_entries > 0
    ? Math.round((data.cache_entries_last_24h / data.total_cache_entries) * 100)
    : 0;

  return (
    <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-8 bg-background">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2"><BarChart2 className="w-6 h-6 text-primary" /> HR Analytics</h2>
        <button onClick={fetchAnalytics} className="p-2 hover:bg-accent rounded-lg transition-colors text-muted-foreground hover:text-foreground">
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Departments',    value: data.department_metrics.length,   color: 'text-blue-400' },
          { label: 'Total Employees',value: totalEmployees,                    color: 'text-green-400' },
          { label: 'Cache Entries',  value: data.total_cache_entries,          color: 'text-purple-400' },
          { label: 'Cache 24h %',    value: `${cacheHitRate}%`,               color: 'text-amber-400' },
          { label: 'Sessions',       value: data.total_sessions,               color: 'text-pink-400' },
          { label: 'Unique Users',   value: data.unique_users,                 color: 'text-cyan-400' },
          { label: 'Cache (24h)',    value: data.cache_entries_last_24h,       color: 'text-indigo-400' },
          { label: 'Query Days',     value: data.query_volume_7d.length,       color: 'text-teal-400' },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-card border border-border rounded-xl p-4 shadow-sm">
            <p className="text-xs font-medium text-muted-foreground mb-1">{label}</p>
            <p className={cn('text-2xl font-bold', color)}>{value}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <h3 className="text-sm font-semibold mb-4 text-muted-foreground uppercase tracking-wider">Avg Salary by Dept</h3>
          <ResponsiveContainer width="100%" height={220}>
            <RechartsBarChart data={data.department_metrics}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="department" stroke="#888" tick={{ fontSize: 11 }} />
              <YAxis stroke="#888" tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e1e1e', borderColor: '#333', fontSize: 12 }} />
              <Bar dataKey="average_salary" fill="#3b82f6" name="Avg Salary ($)" radius={[4, 4, 0, 0]} />
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <h3 className="text-sm font-semibold mb-4 text-muted-foreground uppercase tracking-wider">Query Volume (7 Days)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={data.query_volume_7d}>
              <defs>
                <linearGradient id="qvGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="date" stroke="#888" tick={{ fontSize: 10 }} />
              <YAxis stroke="#888" tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip contentStyle={{ backgroundColor: '#1e1e1e', borderColor: '#333', fontSize: 12 }} />
              <Area type="monotone" dataKey="queries" stroke="#8b5cf6" fill="url(#qvGrad)" strokeWidth={2} name="Queries" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Queries */}
      {data.recent_queries.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <h3 className="text-sm font-semibold mb-4 text-muted-foreground uppercase tracking-wider">Recent Cached Queries</h3>
          <div className="space-y-2">
            {data.recent_queries.map((q, i) => (
              <div key={i} className="flex items-start gap-3 text-sm p-2 rounded-lg hover:bg-accent/50 transition-colors">
                <span className="text-muted-foreground font-mono text-xs mt-0.5 shrink-0">{q.at.substring(0, 16)}</span>
                <span className="text-foreground/80 truncate">{q.query}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ── Document Manager ──────────────────────────────────────────────────────────
const DocumentManager = ({ onToast }: { onToast: (msg: string, type: 'success' | 'error' | 'info') => void }) => {
  const [docs, setDocs] = useState<IngestedDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);

  const fetchDocs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await listDocuments();
      setDocs(res.documents);
    } catch (e) {
      onToast('Failed to load documents', 'error');
    } finally {
      setLoading(false);
    }
  }, [onToast]);

  useEffect(() => { fetchDocs(); }, [fetchDocs]);

  const handleDelete = async (filename: string) => {
    if (!confirm(`Delete all chunks of "${filename}" from the vector store?`)) return;
    setDeleting(filename);
    try {
      const res = await deleteDocument(filename);
      onToast(`Deleted ${res.deleted_chunks} chunks of "${filename}"`, 'success');
      setDocs(prev => prev.filter(d => d.filename !== filename));
    } catch (e) {
      onToast(`Failed to delete "${filename}"`, 'error');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-6 bg-background">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <FolderOpen className="w-6 h-6 text-primary" /> Document Library
        </h2>
        <button onClick={fetchDocs} className="p-2 hover:bg-accent rounded-lg transition-colors text-muted-foreground hover:text-foreground">
          <RefreshCw className={cn('w-4 h-4', loading && 'animate-spin')} />
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <RefreshCw className="w-8 h-8 text-primary animate-spin" />
        </div>
      ) : docs.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center text-muted-foreground space-y-4">
          <FolderOpen className="w-16 h-16 opacity-30" />
          <p className="text-lg font-medium">No documents indexed yet.</p>
          <p className="text-sm">Upload a file using the chat input to get started.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">{docs.length} document{docs.length !== 1 ? 's' : ''} indexed</p>
          {docs.map(doc => (
            <motion.div
              key={doc.filename}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border rounded-xl p-4 flex items-start gap-4 hover:border-primary/30 transition-colors"
            >
              <FileText className="w-8 h-8 text-primary shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{doc.filename}</p>
                <div className="flex items-center gap-3 mt-1 flex-wrap">
                  <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded font-medium">{doc.document_type}</span>
                  <span className="text-xs text-muted-foreground">{doc.chunks} chunk{doc.chunks !== 1 ? 's' : ''}</span>
                </div>
                {doc.summary && (
                  <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">{doc.summary}</p>
                )}
              </div>
              <button
                onClick={() => handleDelete(doc.filename)}
                disabled={deleting === doc.filename}
                className="p-2 hover:bg-destructive/10 rounded-lg transition-colors text-muted-foreground hover:text-destructive disabled:opacity-40"
              >
                {deleting === doc.filename
                  ? <RefreshCw className="w-4 h-4 animate-spin" />
                  : <Trash2 className="w-4 h-4" />
                }
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

// ── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const { t, i18n } = useTranslation();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<string>('HR_Admin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [activeView, setActiveView] = useState<'chat' | 'settings' | 'analytics' | 'documents'>('chat');

  const [feedbackSent, setFeedbackSent] = useState<Record<string, 1 | -1>>({});
  const [toasts, setToasts] = useState<Toast[]>([]);

  const [uploadState, setUploadState] = useState<{ filename: string; pct: number; status: string } | null>(null);

  const [settings, setSettings] = useState<QuerySettings>({
    similarity_top_k: 20,
    rerank_top_n: 5,
    temperature: 0.1,
    user_role: 'HR_Admin',
    framework: 'langgraph',
  });

  const [selectedPdf, setSelectedPdf] = useState<{ filename: string; page: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Helpers
  const addToast = useCallback((message: string, type: Toast['type'] = 'info') => {
    const id = Date.now().toString();
    setToasts(p => [...p, { id, message, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 4000);
  }, []);

  const removeToast = useCallback((id: string) => setToasts(p => p.filter(t => t.id !== id)), []);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  useEffect(() => { setSettings(p => ({ ...p, user_role: userRole })); }, [userRole]);
  useEffect(() => { if (isLoggedIn) getSessions().then(setSessions).catch(console.error); }, [isLoggedIn]);

  const loadSession = async (sessionId: string) => {
    try {
      setCurrentSessionId(sessionId);
      const msgs = await getSessionMessages(sessionId);
      setMessages(msgs);
      setActiveView('chat');
    } catch (e) { console.error(e); }
  };

  const startNewChat = () => { setCurrentSessionId(null); setMessages([]); setActiveView('chat'); };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const data = await login(email, password);
      localStorage.setItem('access_token', data.access_token);
      setUserRole(data.user.role);
      setIsLoggedIn(true);
    } catch (err: any) {
      setError(err.response?.data?.detail || t('auth.error'));
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || isStreaming) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: input };
    const snapshot = [...messages, userMsg];
    setMessages(snapshot);
    setInput('');
    setIsStreaming(true);

    let activeSessionId = currentSessionId;
    if (!activeSessionId) {
      try {
        const title = input.trim().substring(0, 30) + (input.length > 30 ? '...' : '');
        const sess = await createSession(title);
        activeSessionId = sess.session_id;
        setCurrentSessionId(activeSessionId);
        setSessions(prev => [sess, ...prev]);
      } catch (err) { console.error('Session creation error', err); }
    }

    const assistantId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: assistantId, role: 'assistant', content: '' }]);

    try {
      await streamQuery(input, messages, settings,
        chunk => setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, content: m.content + chunk } : m)),
        citations => setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, sources: citations } : m)),
        activeSessionId || undefined,
      );
    } catch (err) {
      console.error(err);
    } finally {
      setIsStreaming(false);
    }
  };

  const handleFeedback = async (msgId: string, rating: 1 | -1) => {
    try {
      await submitFeedback(msgId, rating);
      setFeedbackSent(prev => ({ ...prev, [msgId]: rating }));
      addToast(rating === 1 ? 'Thanks for the feedback! 👍' : 'Feedback noted — we\'ll improve.', 'success');
    } catch (e) { addToast('Could not save feedback.', 'error'); }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    setUploadState({ filename: file.name, pct: 0, status: 'Uploading…' });
    try {
      const res = await uploadPdf(file, pct => setUploadState(s => s ? { ...s, pct } : null));
      setUploadState(s => s ? { ...s, pct: 100, status: 'Processing in background…' } : null);
      addToast(`${file.name} uploaded. Processing…`, 'info');

      // Poll task status if we got a task_id
      if (res.task_id) {
        let attempts = 0;
        const poll = setInterval(async () => {
          attempts++;
          try {
            const st = await getTaskStatus(res.task_id);
            if (st.status === 'success') {
              clearInterval(poll);
              setUploadState(null);
              addToast(`${file.name} indexed successfully!`, 'success');
            } else if (st.status === 'failure') {
              clearInterval(poll);
              setUploadState(null);
              addToast(`Indexing failed: ${st.detail}`, 'error');
            } else if (attempts > 60) {
              clearInterval(poll);
              setUploadState(null);
            }
          } catch { clearInterval(poll); setUploadState(null); }
        }, 5000);
      } else {
        setTimeout(() => setUploadState(null), 1500);
      }

      const systemMsg: ChatMessage = {
        id: Date.now().toString(), role: 'assistant',
        content: `*${file.name}* ${t('chat.upload_async')}`,
      };
      setMessages(prev => [...prev, systemMsg]);
    } catch (err: any) {
      setUploadState(null);
      addToast(`Upload failed: ${err?.response?.data?.detail || err?.message || 'Unknown error'}`, 'error');
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mr;
      audioChunksRef.current = [];
      mr.ondataavailable = e => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      mr.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        try {
          const res = await transcribeAudio(blob);
          if (res.text) setInput(p => p ? p + ' ' + res.text : res.text);
        } catch (e) { console.error('Transcription error:', e); }
        stream.getTracks().forEach(t => t.stop());
      };
      mr.start();
      setIsRecording(true);
    } catch (e) { console.error('Mic error:', e); }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const isAdmin = userRole === 'HR_Admin' || userRole === 'admin';

  // ── Login Screen ────────────────────────────────────────────────────────────
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-card border border-border p-8 rounded-2xl shadow-2xl">
          <div className="flex flex-col items-center mb-8">
            <div className="p-4 bg-primary/10 rounded-2xl mb-4">
              <Shield className="w-12 h-12 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground text-center">{t('welcome.title')}</h1>
            <p className="text-muted-foreground text-center mt-2">{t('welcome.subtitle')}</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            {error && <div className="p-3 bg-destructive/10 border border-destructive/20 text-destructive text-sm rounded-lg">{error}</div>}
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">{t('auth.username')}</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                className="w-full bg-accent border-none rounded-xl p-3 focus:ring-2 focus:ring-primary transition-all"
                placeholder="admin@enterprise.com" required />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">{t('auth.password')}</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                className="w-full bg-accent border-none rounded-xl p-3 focus:ring-2 focus:ring-primary transition-all"
                placeholder="••••••••" required />
            </div>
            <button type="submit"
              className="w-full bg-primary text-primary-foreground font-bold p-4 rounded-xl hover:opacity-90 transition-all flex items-center justify-center gap-2">
              {t('auth.submit')} <ChevronRight className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ── Main Layout ─────────────────────────────────────────────────────────────
  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <ToastContainer toasts={toasts} remove={removeToast} />

      {/* Upload Progress */}
      <AnimatePresence>
        {uploadState && (
          <UploadProgress filename={uploadState.filename} pct={uploadState.pct} status={uploadState.status} />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <div className="w-80 border-r border-border bg-card flex flex-col">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <Shield className="w-8 h-8 text-primary" />
          <span className="font-bold text-xl truncate">LegalAI</span>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {/* Navigation */}
          <div className="space-y-2">
            {[
              { key: 'settings',  label: t('settings.title') || 'Settings',   icon: SettingsIcon, always: true },
              { key: 'analytics', label: 'Analytics',                          icon: BarChart2,    always: isAdmin },
              { key: 'documents', label: 'Document Library',                   icon: FolderOpen,   always: isAdmin },
            ].filter(n => n.always).map(nav => (
              <button key={nav.key}
                onClick={() => setActiveView(nav.key as any)}
                className={cn(
                  'w-full flex items-center justify-between p-3 rounded-xl border transition-colors',
                  activeView === nav.key
                    ? 'bg-primary/10 border-primary text-primary'
                    : 'bg-accent/50 hover:bg-accent border-border/50',
                )}>
                <div className="flex items-center gap-3">
                  <nav.icon className="w-5 h-5" />
                  <span className="font-bold text-sm">{nav.label}</span>
                </div>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>
            ))}

            {/* Language */}
            <div className="flex items-center gap-3 bg-accent/50 p-2 rounded-lg border border-border/50">
              <Languages className="w-4 h-4 text-primary" />
              <select value={i18n.language} onChange={e => i18n.changeLanguage(e.target.value)}
                className="bg-transparent text-sm w-full outline-none">
                <option value="en">English</option>
                <option value="ru">Русский</option>
                <option value="kk">Қазақша</option>
              </select>
            </div>
          </div>

          {/* Chat Sessions */}
          <div className="pt-2 border-t border-border/50 space-y-2">
            <button onClick={startNewChat}
              className="w-full flex items-center gap-3 p-3 bg-primary text-primary-foreground font-bold rounded-xl hover:opacity-90 transition-all justify-center shadow-lg shadow-primary/20">
              <MessageSquare className="w-5 h-5" /> New Chat
            </button>
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider py-2">Previous Chats</div>
            {sessions.map(s => (
              <button key={s.session_id} onClick={() => loadSession(s.session_id)}
                className={cn(
                  'w-full text-left p-3 rounded-xl border transition-colors flex justify-between items-center group',
                  currentSessionId === s.session_id
                    ? 'bg-accent border-primary'
                    : 'bg-transparent border-transparent hover:bg-accent/50',
                )}>
                <span className="truncate text-sm font-medium">{s.title}</span>
                <Trash2
                  onClick={async e => {
                    e.stopPropagation();
                    await deleteSession(s.session_id);
                    setSessions(prev => prev.filter(x => x.session_id !== s.session_id));
                    if (currentSessionId === s.session_id) startNewChat();
                  }}
                  className="w-4 h-4 opacity-0 group-hover:opacity-100 min-w-4 text-muted-foreground hover:text-destructive transition-all"
                />
              </button>
            ))}
          </div>
        </div>

        {/* User Footer */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 p-3 bg-accent rounded-xl">
            <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold">
              {isAdmin ? 'A' : 'E'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold truncate">{isAdmin ? t('settings.admin', 'HR-Admin') : t('settings.employee', 'Employee')}</div>
              <div className="text-[10px] text-muted-foreground uppercase">{userRole}</div>
            </div>
            <button onClick={() => { setIsLoggedIn(false); localStorage.removeItem('access_token'); }}
              className="text-muted-foreground hover:text-destructive transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative bg-background/50 overflow-hidden">
        {/* Settings Panel */}
        {activeView === 'settings' && (
          <div className="flex-1 overflow-y-auto p-6 md:p-10">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <SettingsIcon className="w-6 h-6 text-primary" /> {t('settings.modal_title', 'Generation Settings')}
            </h2>
            <div className="max-w-lg space-y-8">

              {/* Sliders */}
              {[
                { key: 'similarity_top_k', label: t('settings.top_k'), min: 1, max: 50, step: 1 },
                { key: 'rerank_top_n',     label: t('settings.top_n'), min: 1, max: 10, step: 1 },
                { key: 'temperature',      label: t('settings.temperature'), min: 0, max: 1, step: 0.1 },
              ].map(({ key, label, min, max, step }) => (
                <div key={key} className="space-y-2">
                  <div className="flex justify-between items-center text-xs font-bold text-muted-foreground uppercase">
                    <label>{label}</label>
                    <span className="font-mono text-primary">{(settings as any)[key]}</span>
                  </div>
                  <input type="range" min={min} max={max} step={step}
                    value={(settings as any)[key]}
                    onChange={e => {
                      const val = step < 1 ? parseFloat(e.target.value) : parseInt(e.target.value);
                      setSettings(s => ({ ...s, [key]: val }));
                    }}
                    className="w-full h-1.5 bg-accent rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                </div>
              ))}
              <button
                onClick={() => setSettings(s => ({ ...s, framework: 'langgraph', similarity_top_k: 40, rerank_top_n: 8, temperature: 0.1 }))}
                className="px-4 py-2 bg-accent border border-border rounded-xl text-sm font-bold hover:bg-accent/80 transition-colors">
                {t('settings.reset', 'Reset to Defaults')}
              </button>
            </div>
          </div>
        )}

        {activeView === 'analytics' && <AnalyticsDashboard />}
        {activeView === 'documents' && <DocumentManager onToast={addToast} />}

        {/* Chat View */}
        {activeView === 'chat' && (
          <>
            <div className="flex-1 overflow-y-auto p-6 md:p-12 space-y-8 scroll-smooth">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-30 select-none">
                  <MessageSquare className="w-24 h-24 mb-4" />
                  <h2 className="text-2xl font-bold">{t('welcome.title')}</h2>
                  <p className="max-w-md">{t('welcome.subtitle')}</p>
                </div>
              )}

              {messages.map(msg => (
                <div key={msg.id} className={cn('flex gap-4 group', msg.role === 'user' ? 'flex-row-reverse' : 'flex-row')}>
                  <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center shrink-0',
                    msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-muted-foreground')}>
                    {msg.role === 'user' ? <User className="w-6 h-6" /> : <Shield className="w-6 h-6" />}
                  </div>
                  <div className={cn('max-w-[80%] space-y-2', msg.role === 'user' && 'text-right')}>
                    <div className={cn('p-4 rounded-2xl text-sm leading-relaxed shadow-sm overflow-hidden break-words',
                      msg.role === 'user'
                        ? 'bg-primary/95 text-primary-foreground rounded-tr-none whitespace-pre-wrap'
                        : 'bg-card border border-border rounded-tl-none')}>
                      {msg.role === 'user' ? msg.content : formatMessage(msg.content)}
                    </div>

                    {/* Citations */}
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {msg.sources.map((src, i) => (
                          <button key={i}
                            onClick={() => setSelectedPdf({ filename: src.filename, page: src.page })}
                            className="flex items-center gap-2 px-3 py-1.5 bg-accent hover:bg-primary/20 text-[11px] font-bold rounded-lg border border-border transition-all">
                            <FileText className="w-3.5 h-3.5" />
                            {src.filename} (P{src.page})
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Feedback Buttons — only on assistant messages that are complete */}
                    {msg.role === 'assistant' && msg.content && !isStreaming && (
                      <div className="flex items-center gap-1 mt-1">
                        {feedbackSent[msg.id] === undefined ? (
                          <>
                            <button onClick={() => handleFeedback(msg.id, 1)}
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-green-400 hover:bg-green-400/10 transition-colors"
                              title="Good response">
                              <ThumbsUp className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => handleFeedback(msg.id, -1)}
                              className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-400/10 transition-colors"
                              title="Poor response">
                              <ThumbsDown className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <span className={cn('text-[11px] font-medium flex items-center gap-1',
                            feedbackSent[msg.id] === 1 ? 'text-green-400' : 'text-red-400')}>
                            {feedbackSent[msg.id] === 1 ? <ThumbsUp className="w-3 h-3" /> : <ThumbsDown className="w-3 h-3" />}
                            Recorded
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {isStreaming && (
                <div className="flex gap-4 animate-pulse">
                  <div className="w-10 h-10 rounded-xl bg-card border border-border shrink-0" />
                  <div className="bg-card border border-border h-12 w-32 rounded-2xl p-4" />
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Bar */}
            <div className="p-6 border-t border-border bg-card/80 backdrop-blur-xl">
              <div className="max-w-4xl mx-auto flex items-end gap-3 bg-accent rounded-2xl p-3 border border-border/50 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                <label className="p-2 text-muted-foreground hover:text-primary transition-colors cursor-pointer" title="Upload document">
                  <Upload className="w-6 h-6" />
                  <input type="file" className="hidden"
                    accept=".pdf,.docx,.xlsx,.xls,.pptx,.txt,.md,.csv"
                    onChange={handleFileUpload} />
                </label>
                <button type="button"
                  onMouseDown={startRecording} onMouseUp={stopRecording}
                  onMouseLeave={stopRecording} onTouchStart={startRecording} onTouchEnd={stopRecording}
                  className={cn('p-2 transition-colors rounded-full', isRecording
                    ? 'text-red-500 bg-red-500/10 animate-pulse'
                    : 'text-muted-foreground hover:text-primary')}>
                  <Mic className="w-6 h-6" />
                </button>
                <textarea
                  value={input} onChange={e => setInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                  placeholder={t('chat.input_placeholder')}
                  rows={1}
                  className="flex-1 bg-transparent border-none outline-none resize-none py-2 text-sm max-h-48"
                />
                <button onClick={sendMessage} disabled={isStreaming || !input.trim()}
                  className="p-2 bg-primary text-primary-foreground rounded-xl disabled:opacity-30 transition-all shadow-lg shadow-primary/20">
                  <Send className="w-6 h-6" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* PDF Drawer */}
        {selectedPdf && (
          <div className="absolute inset-0 z-50 bg-background/80 backdrop-blur-sm flex justify-end">
            <div className="w-full max-w-4xl bg-card border-l border-border flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
              <div className="p-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-6 h-6 text-primary" />
                  <span className="font-bold">{selectedPdf.filename}</span>
                  <span className="text-xs bg-accent px-2 py-0.5 rounded uppercase font-bold text-muted-foreground">Page {selectedPdf.page}</span>
                </div>
                <button onClick={() => setSelectedPdf(null)} className="p-2 hover:bg-accent rounded-lg transition-colors">
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>
              <div className="flex-1 bg-accent/30 p-2">
                <iframe src={`/api/files/${selectedPdf.filename}#page=${selectedPdf.page}`}
                  className="w-full h-full rounded-lg border border-border shadow-inner" />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
